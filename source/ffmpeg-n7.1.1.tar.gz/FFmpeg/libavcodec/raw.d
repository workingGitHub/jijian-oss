libavcodec/raw.o: libavcodec/raw.c libavutil/macros.h \
  libavutil/avconfig.h libavcodec/avcodec.h libavutil/samplefmt.h \
  libavutil/attributes.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h libavutil/version.h config.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/intfloat.h \
  libavutil/mathematics.h libavutil/rational.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/buffer.h libavutil/channel_layout.h \
  libavutil/dict.h libavutil/frame.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/version_major.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/raw.h
